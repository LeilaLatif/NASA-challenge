It's not much, but I'm proud

I'll finish it, in sha Allah !