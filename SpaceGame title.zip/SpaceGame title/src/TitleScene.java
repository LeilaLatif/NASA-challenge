import java.awt.Color;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JLabel;
import java.awt.Font;

public class TitleScene extends JPanel {
    Font TTNR = new Font ("Times New Roman", Font.BOLD, 50);
    Font TNR = new Font ("Times New Roman", Font.ITALIC, 35);
    Font normalFont = new Font ("Times New Roman", Font.PLAIN, 30);
    
    JPanel titlePanel = new JPanel();
    JLabel titleLabel = new JLabel("Space Mission");
    JPanel subtitlePanel = new JPanel();
    JLabel subtitleLabel = new JLabel("Save your crew!");
    JPanel titleImagePanel = new JPanel();
    JLabel titleImageLabel = new JLabel();
    ImageIcon earth = new ImageIcon("src/e.png");
    JPanel startPanel = new JPanel();
    JButton startButton = new JButton("START");

    public TitleScene() {
        this.setLayout(null);
        this.setBackground(Color.BLACK);
        titlePanel.setBackground(Color.BLACK);
        titlePanel.setBounds(20, 25, 395, 80);
       
        titleLabel.setForeground(Color.white);
        titleLabel.setFont(TTNR);
        titleLabel.setVerticalAlignment(JLabel.CENTER);
        titleLabel.setHorizontalAlignment((JLabel.CENTER));

        subtitlePanel.setBackground(Color.BLACK);
        subtitlePanel.setBounds(55, 100, 325, 70);
        
        subtitleLabel.setForeground(Color.white);
        subtitleLabel.setFont(TNR);

        titleImagePanel.setBackground(Color.BLACK);
        titleImagePanel.setBounds(66, 150, 300, 300);
        titleImageLabel.setIcon(earth);


        startPanel.setBackground(Color. black);
        startPanel.setBounds(120, 470, 200, 80);
        
        startButton.setBackground(Color.BLACK);
        startButton.setForeground(Color.white);
        startButton.setFont(normalFont);
        startButton.setBounds(120, 470, 190, 70);

        titlePanel.add(titleLabel); 
        subtitlePanel.add(subtitleLabel);
        titleImagePanel.add(titleImageLabel);
        startPanel.add(startButton);

        this.add(titlePanel);
        this.add(subtitlePanel);
        this.add(titleImagePanel);
        this.add(startPanel);
    }
}