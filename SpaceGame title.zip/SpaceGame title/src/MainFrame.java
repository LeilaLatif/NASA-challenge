import javax.swing.ImageIcon;
import java.awt.Color;
import javax.swing.JFrame;

public class MainFrame extends JFrame{

    public MainFrame() {
        ImageIcon earth = new ImageIcon("src/e.png");
        this.setIconImage(earth.getImage()); //change icon of frame
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.getContentPane().setBackground(Color.BLACK);
        this.setLayout(null);
        this.setSize(450, 600);

        TitleScene ts = new TitleScene();    
        ts.setBounds(0,0,450, 600);    
        this.add(ts);

        this.setVisible(true);
    }
}
